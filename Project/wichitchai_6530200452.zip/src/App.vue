<template>
<div>
    <HeadTopic />
    <HeadPage />
    <MyHobbies />
    <div class="d-flex justify-content-center  "> 
      <button class="btn btn-outline-primary btn-sm-px- mx-" @click="toggleList()">--- Click Here !!! ---</button>
    </div>
    <div class="m-2" v-if="showSubList">
      <MyRecord /> 
    </div>
    <MyTitle />
  </div>

</template>

<script>

import HeadPage from './components/HeadPage.vue'
import HeadTopic from './components/HeadTopic.vue'
import MyTitle from './components/MyTitle.vue'
import MyHobbies from './components/MyHobbies.vue'
import MyRecord from './components/MyRecord.vue'


export default {
  name: 'App',
  components: {
    HeadTopic,
    HeadPage,
    MyTitle,
    MyHobbies,
    MyRecord
  },
  data(){
    return{
      showSubList: false
    }
  },
  methods:{
    toggleList()
    {
      this.showSubList=!this.showSubList
    }

}
};
</script>

<style>

</style>./components/HeadTopic.vuee
