<template>
    <div>
        <div class="card my-2">
            <div class="card-body bg-info bg-opacity-10">
                <h5 class="card-title">Subject_ID : {{ subject.id }}</h5>
                <div class="card-sub-title">Subject_Name : {{ subject.Subject }}</div>
                <div class="cart-text">Grade_Num :  {{ subject.Grade_Num }} </div>
                <div class="cart-text">Grade_Text:  {{ subject.Grade_Text }} </div>
                <div class="cart-text">Year :  {{ subject.year }} </div>
            </div>
        </div>
        <button class="btn btn-danger" @click="delDetail(subject.id)">Delete</button>
    </div>
</template>

<script>
export default {
    name: 'RecordList',
    props: ["stdID"],
    data() {
        return {
            subject: {}
        }
    },
    mounted() {
        this.fetchData();
    },
    methods: {
        fetchData() {
            fetch('http://localhost:3000/MyRecord/' + this.stdID)
                .then(res => res.json())
                .then(data => (this.subject = data))
                .catch(err => console.log(err.message));
        },
        delDetail(theId) {
            fetch('http://localhost:3000/MyRecord/' + theId, {
                    method: 'DELETE'
                })
                .then(() => {
                    this.$emit('delete');
                })
                .catch(err => console.error(err));
        }
    }
}
</script>

<style>
</style>