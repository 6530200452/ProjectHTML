<template>

      <div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>
        <h3 class="px-5">---------------------------------------------------------------------------------------------------</h3>
          <h3 class="px-5" style="color: blue">--- <i class="bi bi-house-lock"></i> Persernal ---</h3>
          <br>
          <h6 class="px-3">Name : Wichitchai Sapsanoi</h6>
          <h6 class="px-3 ">Age : 20 </h6>
          <h6 class="px-3 ">Gender : Male </h6>
          <h6 class="px-3 " >Email : Wichtichai.s@ku.th</h6>
          <h6 class="px-3 ">Phone : 0981439094</h6>
          <h6 class="px-3 ">Date of Birth : 30 November 2003</h6>
          <h6 class="px-3 ">Address : 223/106 Thung Sukhla Road, Thung Sukhla Subdistrict,Si Racha District, Chonburi 20230</h6>
          <h3 class="px-5">---------------------------------------------------------------------------------------------------</h3>
        </div>
</template>

<script>
export default {
name : "MyTitle"
}
</script>

<style>
h3{
  text-align: center;
  font-size : 45px;
}
h5{
  font-size: 16px;
  text-align: left;
  margin-left: 550px;
}
h6{
  text-align:left;
  margin-left: 700px;

}
</style>