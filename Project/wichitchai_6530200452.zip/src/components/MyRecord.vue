<template>
    <div>
      <ul class="list-group">
        <li v-for="(subject, id) in MyRecord" :key="id" class="list-group-item">
          <a @click="setShow(subject)">
            {{ subject.id }} {{ subject.Subject }} Grade_Num : {{ subject.Grade_Num }}
          </a>
  
          <div v-if="subject.isShow">
            <RecordList :stdID="subject.id" @edit="showEdit" @delete="reload" />
          </div> 
        </li>
      </ul>
      
      <div v-if="isEdit">
        {{ EditId }}
      </div>
  
      <br>
      <br>
      
      <button class="btn btn-success" @click="AddDetail()">Add Your Record</button>
      
      <div class="m-2" v-if="showAdd">
        <AddList @delete="reload" />
      </div>
    </div>
  </template>
  
  <script>
  import RecordList from './RecordList.vue'
  import AddList from './AddList.vue'
  
  export default {
    name: 'MyRecord',
    components: {
      RecordList,
      AddList
    },
    data() {
      return {
        MyRecord: [],
        showAdd: false
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        fetch('http://localhost:3000/MyRecord')
          .then(res => res.json())
          .then(data => this.MyRecord = data)
          .catch(err => console.log(err.message))
      },
      setShow(theId) {
        theId.isShow = !theId.isShow
      },
      reload() {
        this.fetchData()
      },
      AddDetail() {
        this.showAdd = !this.showAdd
      }
    }
  }
  </script>
  
  <style>
  
  </style>
  