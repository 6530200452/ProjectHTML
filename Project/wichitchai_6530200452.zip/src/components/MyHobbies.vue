<template>
<section >

    <div class="row justify-content-center mb-35">
    <h1 class="col text-danger text-center">--- <i class="bi bi-battery-half"></i> MY HOBBIES --- </h1>
</div>

<div class="row justify-content-center py-5">
    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <img src="@/assets/game.jpg" class = "card-img-top">
            <div class="card-body">
                <h3 class="/src/assets/game.jpg">GAME</h3>
                <p class="card-text">My favourite game is Valorant,CSGO,PUBG </p>
                
            </div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <img src="@/assets/bas.jpg" class = "card-img-top ">
            <div class="card-body">
                <h3 class="/src/assets/bas.jpg">BASKETBALL</h3>
                <p class="card-text">My favourite to play Basketball with my friends</p>
                
            </div>
        </div>
    </div>

    <div class="col-lg-3 col-md-6 col-sm-12">
        <div class="card">
            <img src="@/assets/tbtn.jpg" class = "card-img-top">
            <div class="card-body">
                <h3 class="card-title">TABLETANIES</h3>
                <p class="card-text">I like playing Tabletanies because I get to fight 1-1.</p>
                
            </div>
        </div>
    </div>
</div>

<h1 class="col text-primary text-center">--- <i class="bi bi-record2"></i>MY RECORD --- </h1>
</section>
</template>

<script>
export default {
name : 'MyHobbies'
}
</script>

<style>
 
</style>