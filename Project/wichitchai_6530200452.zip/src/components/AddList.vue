<template>
  <div class="card">
    <div class="card-body">
      <form @submit.prevent="handleSubmit()">
        <div class="row">
          <div class="col-lg-4 col-md-4 col-sm-6 mt-2">
            <label for="subId" class="form-label">Subject_ID</label>
            <input type="text" id="subId" class="form-control" v-model.trim="subject.id" />
          </div>

          <div class="col-lg-8 col-md-8 col-sm-6 mt-2">
            <label for="subName" class="form-label">Subject_Name</label>
            <input
              type="text"
              id="subName"
              class="form-control"
              v-model.trim="subject.Subject"
            />
          </div>

          <div class="col-lg-2 col-md-3 col-sm-4 mt-2">
            <label for class="form-label">Grade_Num</label>
            <div class="form-check">
              <input
                class="form-check-input"
                type="radio"
                id="Grade_Num"
                value="3"
                v-model="subject.Grade_Num"
              />
              <label class="form-check-label" for="Grade_Num">3</label>
            </div>

            <div class="form-check">
              <input
                class="form-check-input"
                type="radio"
                id="Grade_Num"
                value="2"
                v-model="subject.Grade_Num"
              />
              <label class="form-check-label" for="Grade_Num">2</label>
            </div>

            <div class="form-check">
              <input
                class="form-check-input"
                type="radio"
                id="Grade_Num"
                value="1"
                v-model="subject.Grade_Num"
              />
              <label class="form-check-label" for="Grade_Num">1</label>
            </div>
          </div>

          <div class="col-lg-2 col-md-3 col-sm-4 mt-2">
            <label for="Grade" class="form-label">Grade_Text</label>
            <select id="Grade" class="form-select" v-model="subject.Grade_Text">
              <option value="A">A</option>
              <option value="B">B</option>
              <option value="C">C</option>
              <option value="D">D</option>
              <option value="F">F</option>
            </select>
          </div>


          <div class="col-lg-4 col-md-4 col-sm-6 mt-2">
            <label for="year" class="form-label">Year</label>
            <input type="text" id="subId" class="form-control" v-model.trim="subject.year" />
          </div>

          <div class="col">
            <button type="submit" class="btn btn-primary">ADD</button>
          </div>
        </div>
      </form>
    </div>

    <div class="alert alert-success mt-2" v-show="addSuccess">
      บันทึกข้อมูล {{ subject.id }} {{ subject.Subject }} Success
    </div>
  </div>
</template>

<script>
export default {
  name: "AddList",
  data() {
    return {
      subject: {
        id: "",
        Subject: "",
        Grade_Num: "",
        Grade_Text: "",
        year: "",
        isShow: false
      },
      MyRecord: [] 
    };
  },
  methods:{
    handleSubmit() {
      let subject ={
        id: this.subject.id,
        Subject: this.subject.Subject,
        Grade_Num: this.subject.Grade_Num,
        year: this.subject.year,
        Grade_Text: this.subject.Grade_Text,
        isShow: false
      }

      fetch('http://localhost:3000/MyRecord',{
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify(subject)
      })
      .then(() => {
        this.addSuccess = true;
        this.$parent.MyRecord.push(subject);
      })
      .catch((err) => {
        this.addError = true
        this.errMessage = err
      })
    }
  }
};
</script>

<style>
</style>