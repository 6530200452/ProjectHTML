<template>
  <section class="container pt-5">
            <div class="port">
                <h1>--- PORTFOLIO ---</h1>
               
            </div>
            <h3 class="px-5">------------------------------------------------------------------</h3>
            <div class="row">
                <div class="col-lg-15 ">
                    <div>
                        <img src="@/assets/html_A.jpg" alt="" height="300" />
                    </div>
                </div>
            <div class="row">   
                <h3 class="px-5">------------------------------------------------------------------</h3>
                <div class="col-lg-15">
                    <div class="display-3 margin-top : 35px; ">Wichtichai Sapsanoi</div>
                    <div class = "container bg-light">
                        <br>
                        My name's Wichitchai Sapsanoi. I'm studying Computer Science 
                        <br>
                        Kasetsart University, Sriracha Campus.
                        <br>
                        I like to study new developments. of current technology and study future careers.
                        <br>
                        In my free time, I like to listen to music. Watch movies and play games on the computer.
                        <br>
                        <br>
                    </div>
                    
                </div>
            </div>
            </div>
            
        </section>
        
</template>

<script>
export default {
name : "HeadPage"
}
</script>

<style>
    .port{
        
        text-align:center;
        margin-top: 20px;
    }
    .port h1{
        font-size: 70px;
    }
    .row{
        text-align:center;
        margin-top: 35px;
    }
</style>